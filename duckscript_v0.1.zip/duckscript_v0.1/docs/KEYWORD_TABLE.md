# 🦆 DuckScript v0.1 — Tabla Completa de Palabras Clave

## Control de Flujo

| DuckScript  | Python    | Ejemplo DuckScript          |
|-------------|-----------|----------------------------|
| `iff`       | `if`      | `iff x > 0:`               |
| `elif`      | `elif`    | `elif x == 0:`             |
| `els`       | `else`    | `els:`                     |
| `whl`       | `while`   | `whl i < 10:`              |
| `fr`        | `for`     | `fr i in rng(10):`         |
| `brk`       | `break`   | `brk`                      |
| `cnt`       | `continue`| `cnt`                      |
| `pass`      | `pass`    | `pass`                     |

## Funciones

| DuckScript  | Python    | Ejemplo DuckScript              |
|-------------|-----------|--------------------------------|
| `fn`        | `def`     | `fn suma(a, b):`               |
| `ret`       | `return`  | `ret a + b`                    |
| `lmb`       | `lambda`  | *(soporte futuro)*             |
| `yld`       | `yield`   | *(soporte futuro)*             |

## Excepciones

| DuckScript  | Python    | Ejemplo DuckScript          |
|-------------|-----------|----------------------------|
| `try`       | `try`     | `try:`                     |
| `ctch`      | `except`  | `ctch ValueError as e:`    |
| `fnl`       | `finally` | `fnl:`                     |
| `rse`       | `raise`   | `rse`                      |

## I/O

| DuckScript  | Python    | Ejemplo DuckScript            |
|-------------|-----------|------------------------------|
| `pr()`      | `print()` | `prn("Hola", nombre)`         |
| `inp()`     | `input()` | `x = inp("Tu nombre: ")`     |
| `qk()`      | *(duck)*  | `qk("Con emoji de pato!")`   |

## Operadores Lógicos

| DuckScript  | Python  | Ejemplo                  |
|-------------|---------|--------------------------|
| `nd`        | `and`   | `x > 0 nd x < 10`        |
| `or`        | `or`    | `x < 0 or x > 10`        |
| `nt`        | `not`   | `nt condicion`            |
| `in`        | `in`    | `"a" in lista`            |
| `is`        | `is`    | `x is nul`                |

## Literales

| DuckScript  | Python  | Valor               |
|-------------|---------|---------------------|
| `tru`       | `True`  | Verdadero           |
| `fls`       | `False` | Falso               |
| `nul`       | `None`  | Nulo                |

## Importaciones

| DuckScript       | Python               |
|-----------------|----------------------|
| `imp math`      | `import math`        |
| `frm os imp path`| `from os import path`|

## Built-in Functions

| DuckScript       | Python              | Descripción            |
|-----------------|---------------------|------------------------|
| `len(x)`        | `len(x)`            | Longitud               |
| `rng(a,b,s)`    | `range(a,b,s)`      | Rango numérico         |
| `str(x)`        | `str(x)`            | A string               |
| `int(x)`        | `int(x)`            | A entero               |
| `flt(x)`        | `float(x)`          | A decimal              |
| `typ(x)`        | `type(x)`           | Tipo                   |
| `abs(x)`        | `abs(x)`            | Valor absoluto         |
| `mx(x)`         | `max(x)`            | Máximo                 |
| `mn(x)`         | `min(x)`            | Mínimo                 |
| `sm(x)`         | `sum(x)`            | Suma                   |
| `sqr(x)`        | `math.sqrt(x)`      | Raíz cuadrada          |
| `flr(x)`        | `math.floor(x)`     | Suelo                  |
| `cil(x)`        | `math.ceil(x)`      | Techo                  |
| `rnd(x,n)`      | `round(x,n)`        | Redondear              |
| `rndi(a,b)`     | `random.randint(a,b)` | Entero aleatorio     |

## Métodos de String

| DuckScript       | Python           | Descripción           |
|-----------------|------------------|-----------------------|
| `.uppr()`       | `.upper()`       | A mayúsculas          |
| `.lwr()`        | `.lower()`       | A minúsculas          |
| `.strp()`       | `.strip()`       | Eliminar espacios     |
| `.splt(sep)`    | `.split(sep)`    | Dividir string        |
| `.rpl(a,b)`     | `.replace(a,b)`  | Reemplazar            |
| `.fnd(sub)`     | `.find(sub)`     | Buscar subcadena      |

## Métodos de Lista

| DuckScript       | Python           | Descripción           |
|-----------------|------------------|-----------------------|
| `.app(item)`    | `.append(item)`  | Añadir al final       |
| `.pop()`        | `.pop()`         | Quitar último         |
| `.pop(i)`       | `.pop(i)`        | Quitar índice i       |
| `.srt()`        | `.sort()`        | Ordenar               |
| `.rvs()`        | `.reverse()`     | Invertir              |
| `.jn(sep)`      | `sep.join(lst)`  | Unir a string         |
| `.len()`        | `len(lst)`       | Longitud              |

## Métodos de Diccionario

| DuckScript       | Python           | Descripción           |
|-----------------|------------------|-----------------------|
| `.ks()`         | `.keys()`        | Claves                |
| `.vls()`        | `.values()`      | Valores               |
| `.gt(k)`        | `.get(k)`        | Obtener por clave     |
| `.gt(k, def)`   | `.get(k, def)`   | Con valor por defecto |

## Constantes

| DuckScript | Valor                   |
|------------|-------------------------|
| `pi`       | 3.14159265358979323846  |
| `inf`      | Infinito positivo       |
| `e_`       | 2.71828182845904523536  |

## Operadores Aritméticos

| Operador | Descripción       | Ejemplo        |
|----------|------------------|----------------|
| `+`      | Suma / Concat     | `a + b`        |
| `-`      | Resta             | `a - b`        |
| `*`      | Producto / Repet  | `a * b`        |
| `/`      | División          | `a / b`        |
| `%`      | Módulo            | `a % b`        |
| `**`     | Potencia          | `a ** b`       |
| `+=`     | Suma y asigna     | `x += 1`       |
| `-=`     | Resta y asigna    | `x -= 1`       |
| `*=`     | Mult. y asigna    | `x *= 2`       |
| `/=`     | Div. y asigna     | `x /= 2`       |

## Operadores de Comparación

| Operador | Descripción      |
|----------|-----------------|
| `==`     | Igual            |
| `!=`     | Distinto         |
| `<`      | Menor que        |
| `<=`     | Menor o igual    |
| `>`      | Mayor que        |
| `>=`     | Mayor o igual    |
