# 🦆 DuckScript — CHANGELOG

---

## v0.1 (Beta) — "Golden Quack" — Windows Edition
**Fecha de lanzamiento:** Febrero 2026

### 🆕 Primera versión pública

#### Motor del lenguaje
- Implementado completamente en **C** (sin dependencias externas)
- **Lexer** con soporte de indentación estilo Python (INDENT/DEDENT)
- **Parser** recursivo descendente con AST completo (40+ tipos de nodo)
- **Intérprete** tree-walk con entornos anidados y closures básicos
- Sistema de **valores dinámicos**: `int`, `float`, `str`, `bool`, `null`, `list`, `dict`, `function`
- Gestión de memoria con **reference counting**

#### Características del lenguaje
- ✅ Variables y asignación (`x = 42`, `x += 1`)
- ✅ Tipos: entero, decimal, string, booleano, nulo, lista, diccionario
- ✅ Operadores aritméticos: `+`, `-`, `*`, `/`, `%`, `**`
- ✅ Operadores de comparación: `==`, `!=`, `<`, `<=`, `>`, `>=`
- ✅ Operadores lógicos: `nd`, `or`, `nt`, `in`
- ✅ Condicionales: `iff / elif / els`
- ✅ Bucle `whl` con `brk` y `cnt`
- ✅ Bucle `fr` sobre listas y rangos
- ✅ Funciones con `fn` y `ret`
- ✅ Recursión soportada
- ✅ Manejo de excepciones: `try / ctch / fnl`
- ✅ Listas: indexación, `.app()`, `.pop()`, `.srt()`, `.rvs()`, `.jn()`
- ✅ Diccionarios: acceso por clave, `.ks()`, `.vls()`, `.gt()`
- ✅ Strings: `.uppr()`, `.lwr()`, `.strp()`, `.splt()`, `.rpl()`, `.fnd()`
- ✅ I/O: `pr()`, `inp()`, `qk()` (con emoji 🦆)
- ✅ Built-ins: `len`, `rng`, `str`, `int`, `flt`, `typ`, `abs`, `mx`, `mn`, `sm`
- ✅ Math: `sqr`, `flr`, `cil`, `rnd`
- ✅ Random: `rndi(a, b)`
- ✅ Constantes: `pi`, `inf`, `e_`

#### Palabras clave (más de 60 abreviaciones)
`prn`, `inp`, `qk`, `iff`, `elif`, `els`, `whl`, `fr`, `brk`, `cnt`, `pass`,
`fn`, `ret`, `lmb`, `yld`, `try`, `ctch`, `fnl`, `rse`, `imp`, `frm`, `as`,
`nd`, `or`, `nt`, `in`, `is`, `glb`, `tru`, `fls`, `nul`, `len`, `rng`,
`str`, `int`, `flt`, `typ`, `abs`, `mx`, `mn`, `sm`, `sqr`, `flr`, `cil`,
`rnd`, `rndi`...

#### Windows Edition
- Soporte nativo de Windows API
- Colores ANSI en la consola (Windows 10+)
- Soporte UTF-8 con emoji 🦆 (`SetConsoleOutputCP(CP_UTF8)`)
- REPL con colores, banner ASCII art, comandos `help`, `cls`
- Compilable con **MinGW-w64 gcc**
- Script `build.bat` incluido

#### Ejemplos incluidos
- `01_hello.duck` — Hola Mundo y tipos básicos
- `02_variables.duck` — Variables y operadores
- `03_control.duck` — if/elif/else/while/for
- `04_funciones.duck` — Funciones, recursión, built-ins
- `05_listas_dicts.duck` — Colecciones
- `06_avanzado.duck` — Excepciones, strings, math, primos, Fibonacci

---

## Próximas versiones (planificado)

### v0.2 — "Wise Duck"
- Clases (`cls`) con herencia
- Métodos de clase con `slf`
- Decoradores básicos

### v0.3 — "Standard Quack"
- Módulo `ducklib` estándar
  - `ducklib.io` — lectura/escritura de archivos
  - `ducklib.math` — funciones matemáticas extendidas
  - `ducklib.str` — utilidades de string avanzadas

### v0.4 — "Advanced Duck"
- Closures completos
- Lambdas (`lmb`) funcionales
- Generadores con `yld`
- List comprehensions nativas

### v0.5 — "Modular Duck"
- Sistema de módulos: `imp mymodule`
- Múltiples archivos `.duck`

### v1.0 — "Production Duck"
- Compilador a bytecode
- VM propia (DuckVM)
- Package manager `quackpkg`
- Debugger integrado
