/*
 * duck_main.c — DuckScript v0.1 Windows Edition
 */
#include "duck.h"

void duck_print_banner(void){
    DUCK_SET_UTF8(); DUCK_ENABLE_ANSI();
    printf("\033[33m");
    printf(" ____             _     ____            _       _   \n");
    printf("|  _ \\ _   _  ___| | __/ ___|  ___ _ __(_)_ __ | |_ \n");
    printf("| | | | | | |/ __| |/ /\\___ \\ / __| '__| | '_ \\| __|\n");
    printf("| |_| | |_| | (__|   <  ___) | (__| |  | | |_) | |_ \n");
    printf("|____/ \\__,_|\\___|_|\\_\\|____/ \\___|_|  |_| .__/ \\__|\n");
    printf("                                          |_|         \n\033[0m");
    printf("\033[36m  \xF0\x9F\xA6\x86  v%s (%s) - Windows Edition\033[0m\n", DUCK_VERSION, DUCK_CODENAME);
    printf("\033[90m  'help' para comandos | 'exit' para salir | archivos .duck\033[0m\n");
    printf("\033[90m  -------------------------------------------------------\033[0m\n\n");
}

void duck_print_help(void){
    DUCK_SET_UTF8();
    printf("\n\033[36m\xF0\x9F\xA6\x86  DuckScript v0.1 - Referencia de palabras clave\033[0m\n");
    printf("\033[90m  ----------------------------------------------------------\033[0m\n");
    printf("  \033[33m%-14s\033[0m \033[32m%-18s\033[0m %s\n","DuckScript","Python","Descripcion");
    printf("\033[90m  ----------------------------------------------------------\033[0m\n");
    static const char *t[][3]={
        {"prn()","print()","Imprimir en consola"},
        {"inp()","input()","Leer entrada"},
        {"qk()","print(duck,)","Print con emoji \xF0\x9F\xA6\x86"},
        {"iff","if","Condicional"},
        {"elif","elif","Si no si"},
        {"els","else","Si no"},
        {"whl","while","Bucle mientras"},
        {"fr ... in","for ... in","Bucle para"},
        {"brk","break","Romper bucle"},
        {"cnt","continue","Continuar bucle"},
        {"fn","def","Definir funcion"},
        {"ret","return","Retornar valor"},
        {"try","try","Bloque try"},
        {"ctch","except","Capturar excepcion"},
        {"fnl","finally","Bloque finally"},
        {"nd","and","Y logico"},
        {"or","or","O logico"},
        {"nt","not","No logico"},
        {"in","in","Pertenencia"},
        {"tru","True","Verdadero"},
        {"fls","False","Falso"},
        {"nul","None","Nulo"},
        {"len()","len()","Longitud"},
        {"rng(a,b,s)","range()","Rango numerico"},
        {"str()","str()","A texto"},
        {"int()","int()","A entero"},
        {"flt()","float()","A decimal"},
        {"typ()","type()","Tipo de dato"},
        {"abs()","abs()","Valor absoluto"},
        {"mx()","max()","Maximo"},
        {"mn()","min()","Minimo"},
        {"sm()","sum()","Suma de lista"},
        {"sqr()","sqrt()","Raiz cuadrada"},
        {"flr()","floor()","Redondeo bajo"},
        {"cil()","ceil()","Redondeo alto"},
        {"rnd(x,n)","round()","Redondear"},
        {"rndi(a,b)","randint()","Entero aleatorio"},
        {".uppr()",".upper()","Mayusculas"},
        {".lwr()",".lower()","Minusculas"},
        {".strp()",".strip()","Quitar espacios"},
        {".splt(sep)",".split()","Dividir string"},
        {".rpl(a,b)",".replace()","Reemplazar"},
        {".fnd(s)",".find()","Buscar"},
        {".app(item)",".append()","Anadir a lista"},
        {".pop()",".pop()","Quitar ultimo"},
        {".srt()",".sort()","Ordenar lista"},
        {".rvs()",".reverse()","Invertir lista"},
        {".jn(sep)","join()","Unir lista"},
        {".ks()",".keys()","Claves dict"},
        {".vls()",".values()","Valores dict"},
        {".gt(k)",".get(k)","Obtener de dict"},
        {NULL,NULL,NULL}
    };
    for(int i=0;t[i][0];i++)
        printf("  \033[33m%-14s\033[0m \033[32m%-18s\033[0m %s\n",t[i][0],t[i][1],t[i][2]);
    printf("\n  \033[36mConstantes:\033[0m pi, inf, e_\n");
    printf("  \033[36mUso:\033[0m duck.exe archivo.duck\n\n");
}

static void run_source(const char *src){
    int tc=0;
    DuckToken *toks=duck_lex(src,&tc);
    DuckNode  *prog=duck_parse(toks,tc);
    DuckInterp ip={0};
    ip.global_env=env_new(NULL);
    interp_run(&ip,prog);
    free(toks);
    env_free(ip.global_env);
}

static void run_file(const char *path){
    const char *ext=strrchr(path,'.');
    if(!ext||strcmp(ext,".duck")!=0)
        fprintf(stderr,"\033[33m[DuckScript] Aviso: '%s' no tiene extension .duck\033[0m\n",path);
    FILE *f=fopen(path,"rb");
    if(!f){fprintf(stderr,"\033[31m[DuckScript] No se puede abrir: '%s'\033[0m\n",path);exit(1);}
    fseek(f,0,SEEK_END); long sz=ftell(f); rewind(f);
    char *src=malloc(sz+1); fread(src,1,sz,f); src[sz]='\0'; fclose(f);
    run_source(src); free(src);
}

void duck_repl(void){
    duck_print_banner();
    DUCK_SET_UTF8();
    DuckInterp ip={0};
    ip.global_env=env_new(NULL);
    char line[MAX_STR];
    char blk[MAX_SOURCE]; blk[0]='\0';
    int in_blk=0;

    while(1){
        DUCK_SET_UTF8();
        printf(in_blk?"\033[36m  ...  \033[0m":"\033[33mduck>\033[0m ");
        fflush(stdout);
        if(!fgets(line,MAX_STR,stdin)){printf("\n\033[33m\xF0\x9F\xA6\x86  Quack! Adios!\033[0m\n");break;}
        int len=(int)strlen(line);
        if(len>0&&line[len-1]=='\n') line[--len]='\0';
        if(!strcmp(line,"exit")||!strcmp(line,"quit")){printf("\033[33m\xF0\x9F\xA6\x86  Quack! Adios!\033[0m\n");break;}
        if(!strcmp(line,"help")){duck_print_help();continue;}
        if(!strcmp(line,"cls")||!strcmp(line,"clear")){
            #ifdef _WIN32
            system("cls");
            #else
            system("clear");
            #endif
            duck_print_banner(); continue;
        }
        if(len>0&&line[len-1]==':'){in_blk=1;strncat(blk,line,MAX_SOURCE-strlen(blk)-1);strncat(blk,"\n",MAX_SOURCE-strlen(blk)-1);continue;}
        if(in_blk){
            if(len==0){
                in_blk=0; int tc=0;
                DuckToken *toks=duck_lex(blk,&tc); DuckNode *prog=duck_parse(toks,tc);
                ip.had_error=0;ip.returning=0;
                DuckValue *r=interp_run(&ip,prog); value_free(r); free(toks); blk[0]='\0';
            } else {
                strncat(blk,"    ",MAX_SOURCE-strlen(blk)-1);
                strncat(blk,line,MAX_SOURCE-strlen(blk)-1);
                strncat(blk,"\n",MAX_SOURCE-strlen(blk)-1);
            }
            continue;
        }
        int tc=0;
        DuckToken *toks=duck_lex(line,&tc); DuckNode *prog=duck_parse(toks,tc);
        ip.had_error=0; ip.returning=0;
        DuckValue *result=interp_run(&ip,prog);
        if(!ip.had_error&&result&&result->type!=DVAL_NULL){
            DUCK_SET_UTF8();
            char *s=val_to_str(result);
            printf("\033[32m=> %s\033[0m\n",s); free(s);
        }
        value_free(result); free(toks);
    }
    env_free(ip.global_env);
}

int main(int argc, char **argv){
    DUCK_SET_UTF8();
    if(argc<2){duck_repl();return 0;}
    if(!strcmp(argv[1],"--help")||!strcmp(argv[1],"-h")){duck_print_banner();duck_print_help();return 0;}
    if(!strcmp(argv[1],"--version")||!strcmp(argv[1],"-v")){printf("DuckScript v%s (%s)\n",DUCK_VERSION,DUCK_CODENAME);return 0;}
    run_file(argv[1]); return 0;
}
