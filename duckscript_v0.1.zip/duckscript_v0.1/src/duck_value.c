/*
 * duck_value.c — DuckScript v0.1 Value System
 */
#include "duck.h"

DuckValue *make_int(long long v)   { DuckValue *d=calloc(1,sizeof*d); d->type=DVAL_INT;   d->as.ival=v;    d->ref_count=1; return d; }
DuckValue *make_float(double v)    { DuckValue *d=calloc(1,sizeof*d); d->type=DVAL_FLOAT; d->as.fval=v;    d->ref_count=1; return d; }
DuckValue *make_bool(int v)        { DuckValue *d=calloc(1,sizeof*d); d->type=DVAL_BOOL;  d->as.bval=v?1:0;d->ref_count=1; return d; }
DuckValue *make_null(void)         { DuckValue *d=calloc(1,sizeof*d); d->type=DVAL_NULL;                   d->ref_count=1; return d; }

DuckValue *make_string(const char *s) {
    DuckValue *d=calloc(1,sizeof*d);
    d->type=DVAL_STRING; d->as.sval=strdup(s?s:""); d->ref_count=1; return d;
}
DuckValue *make_list(void) {
    DuckValue *d=calloc(1,sizeof*d);
    d->type=DVAL_LIST; d->as.list.cap=8;
    d->as.list.items=calloc(8,sizeof(DuckValue*)); d->ref_count=1; return d;
}
DuckValue *make_error(const char *fmt,...) {
    DuckValue *d=calloc(1,sizeof*d); d->type=DVAL_ERROR;
    char buf[MAX_STR]; va_list ap; va_start(ap,fmt); vsnprintf(buf,MAX_STR,fmt,ap); va_end(ap);
    d->as.sval=strdup(buf); d->ref_count=1; return d;
}

void list_push(DuckValue *lst, DuckValue *item) {
    if(lst->as.list.count>=lst->as.list.cap){
        lst->as.list.cap*=2;
        lst->as.list.items=realloc(lst->as.list.items, lst->as.list.cap*sizeof(DuckValue*));
    }
    lst->as.list.items[lst->as.list.count++]=item;
}

void value_free(DuckValue *v) {
    if(!v||--v->ref_count>0) return;
    switch(v->type){
        case DVAL_STRING: case DVAL_ERROR: free(v->as.sval); break;
        case DVAL_LIST:
            for(int i=0;i<v->as.list.count;i++) value_free(v->as.list.items[i]);
            free(v->as.list.items); break;
        case DVAL_DICT:
            for(int i=0;i<v->as.dict.count;i++){free(v->as.dict.keys[i]);value_free(v->as.dict.vals[i]);}
            free(v->as.dict.keys); free(v->as.dict.vals); break;
        default: break;
    }
    free(v);
}

char *val_to_str(DuckValue *v) {
    if(!v) return strdup("nul");
    char buf[MAX_STR];
    switch(v->type){
        case DVAL_INT:   snprintf(buf,MAX_STR,"%lld",v->as.ival); return strdup(buf);
        case DVAL_FLOAT: {
            snprintf(buf,MAX_STR,"%.10g",v->as.fval);
            if(!strchr(buf,'.')&&!strchr(buf,'e')) strcat(buf,".0");
            return strdup(buf);
        }
        case DVAL_STRING: return strdup(v->as.sval);
        case DVAL_BOOL:  return strdup(v->as.bval?"tru":"fls");
        case DVAL_NULL:  return strdup("nul");
        case DVAL_ERROR: { snprintf(buf,MAX_STR,"Error:%s",v->as.sval); return strdup(buf); }
        case DVAL_FUNCTION: {
            snprintf(buf,MAX_STR,"<fn %s>",v->as.func.name?v->as.func.name:"?"); return strdup(buf);
        }
        case DVAL_LIST: {
            char out[MAX_STR]; out[0]='['; out[1]='\0';
            for(int i=0;i<v->as.list.count;i++){
                if(i>0) strncat(out,", ",MAX_STR-strlen(out)-1);
                char *s=val_to_str(v->as.list.items[i]);
                if(v->as.list.items[i]->type==DVAL_STRING){
                    strncat(out,"\"",MAX_STR-strlen(out)-1);
                    strncat(out,s,MAX_STR-strlen(out)-1);
                    strncat(out,"\"",MAX_STR-strlen(out)-1);
                } else strncat(out,s,MAX_STR-strlen(out)-1);
                free(s);
            }
            strncat(out,"]",MAX_STR-strlen(out)-1); return strdup(out);
        }
        case DVAL_DICT: {
            char out[MAX_STR]; out[0]='{'; out[1]='\0';
            for(int i=0;i<v->as.dict.count;i++){
                if(i>0) strncat(out,", ",MAX_STR-strlen(out)-1);
                strncat(out,"\"",MAX_STR-strlen(out)-1);
                strncat(out,v->as.dict.keys[i],MAX_STR-strlen(out)-1);
                strncat(out,"\": ",MAX_STR-strlen(out)-1);
                char *s=val_to_str(v->as.dict.vals[i]);
                strncat(out,s,MAX_STR-strlen(out)-1); free(s);
            }
            strncat(out,"}",MAX_STR-strlen(out)-1); return strdup(out);
        }
        default: return strdup("?");
    }
}

int val_truthy(DuckValue *v){
    if(!v) return 0;
    switch(v->type){
        case DVAL_BOOL:  return v->as.bval;
        case DVAL_INT:   return v->as.ival!=0;
        case DVAL_FLOAT: return v->as.fval!=0.0;
        case DVAL_STRING:return v->as.sval[0]!='\0';
        case DVAL_NULL:  return 0;
        case DVAL_LIST:  return v->as.list.count>0;
        default: return 1;
    }
}

DuckValue *val_add(DuckValue *a, DuckValue *b){
    if(a->type==DVAL_INT&&b->type==DVAL_INT) return make_int(a->as.ival+b->as.ival);
    if((a->type==DVAL_INT||a->type==DVAL_FLOAT)&&(b->type==DVAL_INT||b->type==DVAL_FLOAT)){
        double av=(a->type==DVAL_INT)?(double)a->as.ival:a->as.fval;
        double bv=(b->type==DVAL_INT)?(double)b->as.ival:b->as.fval;
        return make_float(av+bv);
    }
    if(a->type==DVAL_STRING&&b->type==DVAL_STRING){
        size_t n=strlen(a->as.sval)+strlen(b->as.sval)+1;
        char *s=malloc(n); strcpy(s,a->as.sval); strcat(s,b->as.sval);
        DuckValue *r=make_string(s); free(s); return r;
    }
    if(a->type==DVAL_LIST&&b->type==DVAL_LIST){
        DuckValue *r=make_list();
        for(int i=0;i<a->as.list.count;i++){a->as.list.items[i]->ref_count++;list_push(r,a->as.list.items[i]);}
        for(int i=0;i<b->as.list.count;i++){b->as.list.items[i]->ref_count++;list_push(r,b->as.list.items[i]);}
        return r;
    }
    return make_error("Cannot add types");
}

DuckValue *val_cmp(DuckValue *a, DuckValue *b, DuckTokType op){
    int r=0;
    if((a->type==DVAL_INT||a->type==DVAL_FLOAT)&&(b->type==DVAL_INT||b->type==DVAL_FLOAT)){
        double av=(a->type==DVAL_INT)?(double)a->as.ival:a->as.fval;
        double bv=(b->type==DVAL_INT)?(double)b->as.ival:b->as.fval;
        switch(op){case DTOK_EQ:r=av==bv;break;case DTOK_NEQ:r=av!=bv;break;
                   case DTOK_LT:r=av<bv;break; case DTOK_LE:r=av<=bv;break;
                   case DTOK_GT:r=av>bv;break; case DTOK_GE:r=av>=bv;break;default:break;}
    } else if(a->type==DVAL_STRING&&b->type==DVAL_STRING){
        int c=strcmp(a->as.sval,b->as.sval);
        switch(op){case DTOK_EQ:r=c==0;break;case DTOK_NEQ:r=c!=0;break;
                   case DTOK_LT:r=c<0;break; case DTOK_LE:r=c<=0;break;
                   case DTOK_GT:r=c>0;break; case DTOK_GE:r=c>=0;break;default:break;}
    } else if(a->type==DVAL_NULL&&b->type==DVAL_NULL) r=(op==DTOK_EQ);
    else { r=(op==DTOK_NEQ); }
    return make_bool(r);
}
