#ifndef DUCK_H
#define DUCK_H

/*
 * ██████╗ ██╗   ██╗ ██████╗██╗  ██╗███████╗ ██████╗██████╗ ██╗██████╗ ████████╗
 * ██╔══██╗██║   ██║██╔════╝██║ ██╔╝██╔════╝██╔════╝██╔══██╗██║██╔══██╗╚══██╔══╝
 * ██║  ██║██║   ██║██║     █████╔╝ ███████╗██║     ██████╔╝██║██████╔╝   ██║
 * ██║  ██║██║   ██║██║     ██╔═██╗ ╚════██║██║     ██╔══██╗██║██╔═══╝    ██║
 * ██████╔╝╚██████╔╝╚██████╗██║  ██╗███████║╚██████╗██║  ██║██║██║        ██║
 * ╚═════╝  ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝
 *
 *  DuckScript v0.1 (Beta) - Windows Edition
 *  Extension: .duck | No external dependencies
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <time.h>
#include <stdarg.h>

/* Windows console helpers - only what we need */
#ifdef _WIN32
#  include <windows.h>
#  define DUCK_SET_UTF8()  SetConsoleOutputCP(65001)
#  define DUCK_ENABLE_ANSI() do { \
       HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE); \
       DWORD m = 0; GetConsoleMode(h,&m); \
       SetConsoleMode(h, m | 0x0004); \
   } while(0)
#else
#  define DUCK_SET_UTF8()
#  define DUCK_ENABLE_ANSI()
#endif

#define DUCK_VERSION  "0.1"
#define DUCK_CODENAME "Golden Quack"
#define MAX_TOKENS    8192
#define MAX_SOURCE    1048576
#define MAX_VARS      512
#define MAX_CALL_STACK 256
#define MAX_STR       4096
#define MAX_ARGS      32
#define MAX_PARAMS    32
#define MAX_ARRAY     1024

/* ─── Token types  (prefixed DTOK_ to avoid Windows clash) ─── */
typedef enum {
    DTOK_INT, DTOK_FLOAT, DTOK_STRING, DTOK_BOOL, DTOK_NULL,
    DTOK_IDENT,
    /* DuckScript keywords */
    DTOK_PRN,   /* prn  */
    DTOK_INP,   /* inp  */
    DTOK_QK,    /* qk   */
    DTOK_IFF,   /* iff  */
    DTOK_ELS,   /* els  */
    DTOK_ELIF,  /* elif */
    DTOK_FR,    /* fr   */
    DTOK_WHL,   /* whl  */
    DTOK_BRK,   /* brk  */
    DTOK_CNT,   /* cnt  */
    DTOK_FN,    /* fn   */
    DTOK_RET,   /* ret  */
    DTOK_LMB,   /* lmb  */
    DTOK_YLD,   /* yld  */
    DTOK_TRY,   /* try  */
    DTOK_CTCH,  /* ctch */
    DTOK_FNL,   /* fnl  */
    DTOK_RSE,   /* rse  */
    DTOK_IMP,   /* imp  */
    DTOK_FRM,   /* frm  */
    DTOK_AS,    /* as   */
    DTOK_GLB,   /* glb  */
    DTOK_PASS,  /* pass */
    DTOK_ND,    /* nd   */
    DTOK_OR,    /* or   */
    DTOK_NT,    /* nt   */
    DTOK_IN,    /* in   */
    DTOK_IS,    /* is   */
    /* Operators */
    DTOK_PLUS, DTOK_MINUS, DTOK_STAR, DTOK_SLASH,
    DTOK_PERCENT, DTOK_DSTAR,
    DTOK_EQ, DTOK_NEQ, DTOK_LT, DTOK_LE, DTOK_GT, DTOK_GE,
    DTOK_ASSIGN,
    DTOK_PLUS_EQ, DTOK_MINUS_EQ, DTOK_STAR_EQ, DTOK_SLASH_EQ,
    DTOK_LPAREN, DTOK_RPAREN,
    DTOK_LBRACE, DTOK_RBRACE,
    DTOK_LBRACKET, DTOK_RBRACKET,
    DTOK_COMMA, DTOK_COLON, DTOK_DOT,
    DTOK_NEWLINE, DTOK_INDENT, DTOK_DEDENT,
    DTOK_EOF
} DuckTokType;

/* ─── Value types (prefixed DVAL_) ─── */
typedef enum {
    DVAL_INT, DVAL_FLOAT, DVAL_STRING, DVAL_BOOL, DVAL_NULL,
    DVAL_LIST, DVAL_DICT, DVAL_FUNCTION, DVAL_ERROR
} DuckValType;

/* ─── AST node types (prefixed DNODE_) ─── */
typedef enum {
    DNODE_BLOCK,
    DNODE_ASSIGN,
    DNODE_AUG_ASSIGN,
    DNODE_IF,
    DNODE_WHILE,
    DNODE_FOR,
    DNODE_FUNC_DEF,
    DNODE_RETURN,
    DNODE_BREAK,
    DNODE_CONTINUE,
    DNODE_PASS,
    DNODE_PRINT,
    DNODE_INPUT,
    DNODE_TRY,
    DNODE_BINARY,
    DNODE_UNARY,
    DNODE_CALL,
    DNODE_ATTR,
    DNODE_SUBSCRIPT,
    DNODE_LIST_LIT,
    DNODE_DICT_LIT,
    DNODE_INT_LIT,
    DNODE_FLOAT_LIT,
    DNODE_STR_LIT,
    DNODE_BOOL_LIT,
    DNODE_NULL_LIT,
    DNODE_IDENT
} DuckNodeType;

/* forward decls */
struct DuckValue;
struct DuckEnv;
struct DuckNode;

/* ─── Token ─── */
typedef struct {
    DuckTokType type;
    char        lexeme[MAX_STR];
    int         line;
    struct { long long ival; double fval; int bval; } lit;  /* struct not union - no overlap */
} DuckToken;

/* ─── Value ─── */
typedef struct DuckValue {
    DuckValType type;
    union {
        long long ival;
        double    fval;
        char     *sval;
        int       bval;
        struct {
            struct DuckValue **items;
            int count, cap;
        } list;
        struct {
            char             **keys;
            struct DuckValue **vals;
            int count;
        } dict;
        struct {
            char            **params;
            int               param_count;
            struct DuckNode  *body;
            struct DuckEnv   *closure;
            char             *name;
        } func;
    } as;
    int ref_count;
} DuckValue;

/* ─── AST Node ─── */
typedef struct DuckNode {
    DuckNodeType type;
    int line;
    union {
        struct { struct DuckNode **stmts; int count; } block;
        struct { long long val; } int_lit;
        struct { double    val; } flt_lit;
        struct { char     *val; } str_lit;
        struct { int       val; } bool_lit;
        struct { char     *name; } ident;
        struct {
            char           *target;
            struct DuckNode *value;
            DuckTokType     op;
        } assign;
        struct {
            DuckTokType     op;
            struct DuckNode *left, *right;
        } binary;
        struct {
            DuckTokType     op;
            struct DuckNode *operand;
        } unary;
        struct {
            struct DuckNode  *callee;
            struct DuckNode **args;
            int               argc;
        } call;
        struct {
            struct DuckNode *obj;
            char            *attr;
        } attr;
        struct {
            struct DuckNode *obj, *index;
        } sub;
        struct {
            struct DuckNode *cond, *then_br, *else_br;
            struct DuckNode **elif_conds, **elif_brs;
            int              elif_count;
        } if_s;
        struct {
            struct DuckNode *cond, *body;
        } while_s;
        struct {
            char            *var;
            struct DuckNode *iterable, *body;
        } for_s;
        struct {
            char            *name;
            char           **params;
            int              param_count;
            struct DuckNode *body;
        } func_def;
        struct { struct DuckNode *value; } ret;
        struct {
            struct DuckNode **args;
            int               argc;
            int               is_qk;
            char             *sep, *end;
        } print;
        struct {
            struct DuckNode *prompt;
            char            *target;
        } input;
        struct {
            struct DuckNode *body, *catch_body, *finally_body;
            char *exc_type, *exc_var;
        } try_s;
        struct {
            struct DuckNode **items;
            int count;
        } list_lit;
        struct {
            struct DuckNode **keys, **vals;
            int count;
        } dict_lit;
    } as;
} DuckNode;

/* ─── Environment ─── */
typedef struct DuckEnv {
    char       *names[MAX_VARS];
    DuckValue  *values[MAX_VARS];
    int         count;
    struct DuckEnv *parent;
} DuckEnv;

/* ─── Interpreter ─── */
typedef struct {
    DuckEnv  *global_env;
    int       had_error;
    char      error_msg[MAX_STR];
    int       returning, breaking, continuing;
    DuckValue *return_value;
} DuckInterp;

/* ─── API ─── */
DuckToken *duck_lex   (const char *src, int *out_count);
DuckNode  *duck_parse (DuckToken *tokens, int count);
DuckValue *interp_run (DuckInterp *ip, DuckNode *program);

DuckEnv   *env_new    (DuckEnv *parent);
void       env_free   (DuckEnv *e);
DuckValue *env_get    (DuckEnv *e, const char *name);
void       env_set    (DuckEnv *e, const char *name, DuckValue *val);
int        env_update (DuckEnv *e, const char *name, DuckValue *val);

DuckValue *make_int   (long long v);
DuckValue *make_float (double v);
DuckValue *make_string(const char *s);
DuckValue *make_bool  (int v);
DuckValue *make_null  (void);
DuckValue *make_list  (void);
DuckValue *make_error (const char *fmt, ...);
void       value_free (DuckValue *v);
char      *val_to_str (DuckValue *v);
int        val_truthy (DuckValue *v);
DuckValue *val_add    (DuckValue *a, DuckValue *b);
DuckValue *val_cmp    (DuckValue *a, DuckValue *b, DuckTokType op);
void       list_push  (DuckValue *list, DuckValue *item);

void duck_print_banner(void);
void duck_print_help  (void);
void duck_repl        (void);

#endif /* DUCK_H */
