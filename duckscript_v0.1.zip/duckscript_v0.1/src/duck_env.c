/*
 * duck_env.c — DuckScript v0.1 Environment
 */
#include "duck.h"

DuckEnv *env_new(DuckEnv *parent){
    DuckEnv *e=calloc(1,sizeof*e); e->parent=parent; return e;
}
void env_free(DuckEnv *e){
    if(!e) return;
    for(int i=0;i<e->count;i++){free(e->names[i]);value_free(e->values[i]);}
    free(e);
}
DuckValue *env_get(DuckEnv *e, const char *name){
    for(DuckEnv *cur=e;cur;cur=cur->parent)
        for(int i=0;i<cur->count;i++)
            if(strcmp(cur->names[i],name)==0) return cur->values[i];
    return NULL;
}
void env_set(DuckEnv *e, const char *name, DuckValue *val){
    for(int i=0;i<e->count;i++){
        if(strcmp(e->names[i],name)==0){
            value_free(e->values[i]); e->values[i]=val; val->ref_count++; return;
        }
    }
    if(e->count>=MAX_VARS){fprintf(stderr,"DuckScript: too many variables\n");exit(1);}
    e->names[e->count]=strdup(name); e->values[e->count]=val; val->ref_count++; e->count++;
}
int env_update(DuckEnv *e, const char *name, DuckValue *val){
    for(DuckEnv *cur=e;cur;cur=cur->parent)
        for(int i=0;i<cur->count;i++)
            if(strcmp(cur->names[i],name)==0){
                value_free(cur->values[i]); cur->values[i]=val; val->ref_count++; return 1;
            }
    return 0;
}
