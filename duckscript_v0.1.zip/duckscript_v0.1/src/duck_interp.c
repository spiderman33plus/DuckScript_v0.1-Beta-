/*
 * duck_interp.c — DuckScript v0.1 Interpreter
 */
#include "duck.h"
#include <math.h>

static DuckValue *deval(DuckInterp *ip, DuckNode *node, DuckEnv *env);
static DuckValue *dexec_block(DuckInterp *ip, DuckNode *blk, DuckEnv *env);

static void duck_error(DuckInterp *ip, int line, const char *fmt, ...){
    ip->had_error=1;
    va_list ap; va_start(ap,fmt); vsnprintf(ip->error_msg,MAX_STR,fmt,ap); va_end(ap);
    fprintf(stderr,"\n[DuckScript RuntimeError line %d]: %s\n",line,ip->error_msg);
}

/* ── Built-ins ── */
static DuckValue *b_len(DuckValue **a,int c){
    if(c!=1) return make_error("len() takes 1 arg");
    switch(a[0]->type){
        case DVAL_STRING: return make_int(strlen(a[0]->as.sval));
        case DVAL_LIST:   return make_int(a[0]->as.list.count);
        case DVAL_DICT:   return make_int(a[0]->as.dict.count);
        default: return make_error("len() unsupported type");
    }
}
static DuckValue *b_rng(DuckValue **a,int c){
    long long s=0,e=0,st=1;
    if(c==1) e=a[0]->as.ival;
    else if(c==2){s=a[0]->as.ival;e=a[1]->as.ival;}
    else if(c==3){s=a[0]->as.ival;e=a[1]->as.ival;st=a[2]->as.ival;}
    else return make_error("rng() takes 1-3 args");
    if(st==0) return make_error("rng() step=0");
    DuckValue *lst=make_list();
    for(long long i=s;(st>0)?i<e:i>e;i+=st) list_push(lst,make_int(i));
    return lst;
}
static DuckValue *b_str(DuckValue **a,int c){
    if(c!=1) return make_error("str() takes 1 arg");
    char *s=val_to_str(a[0]); DuckValue *r=make_string(s); free(s); return r;
}
static DuckValue *b_int(DuckValue **a,int c){
    if(c!=1) return make_error("int() takes 1 arg");
    switch(a[0]->type){case DVAL_INT:return make_int(a[0]->as.ival);
        case DVAL_FLOAT:return make_int((long long)a[0]->as.fval);
        case DVAL_STRING:return make_int(atoll(a[0]->as.sval));
        case DVAL_BOOL:return make_int(a[0]->as.bval); default:return make_error("Cannot int()"); }
}
static DuckValue *b_flt(DuckValue **a,int c){
    if(c!=1) return make_error("flt() takes 1 arg");
    switch(a[0]->type){case DVAL_INT:return make_float((double)a[0]->as.ival);
        case DVAL_FLOAT:return make_float(a[0]->as.fval);
        case DVAL_STRING:return make_float(atof(a[0]->as.sval)); default:return make_error("Cannot flt()"); }
}
static DuckValue *b_typ(DuckValue **a,int c){
    if(c!=1) return make_error("typ() takes 1 arg");
    switch(a[0]->type){
        case DVAL_INT:    return make_string("int");
        case DVAL_FLOAT:  return make_string("float");
        case DVAL_STRING: return make_string("str");
        case DVAL_BOOL:   return make_string("bool");
        case DVAL_NULL:   return make_string("null");
        case DVAL_LIST:   return make_string("list");
        case DVAL_DICT:   return make_string("dict");
        default:          return make_string("fn");
    }
}
static DuckValue *b_abs(DuckValue**a,int c){
    if(c!=1) return make_error("abs() takes 1 arg");
    if(a[0]->type==DVAL_INT)   return make_int((long long)fabs((double)a[0]->as.ival));
    if(a[0]->type==DVAL_FLOAT) return make_float(fabs(a[0]->as.fval));
    return make_error("abs() needs number");
}
static DuckValue *b_max(DuckValue**a,int c){
    DuckValue **items; int n;
    if(c==1&&a[0]->type==DVAL_LIST){items=a[0]->as.list.items;n=a[0]->as.list.count;}
    else{items=a;n=c;}
    if(n==0) return make_error("mx() empty");
    DuckValue *best=items[0];
    for(int i=1;i<n;i++){DuckValue*cmp=val_cmp(items[i],best,DTOK_GT);if(val_truthy(cmp))best=items[i];value_free(cmp);}
    best->ref_count++; return best;
}
static DuckValue *b_min(DuckValue**a,int c){
    DuckValue **items; int n;
    if(c==1&&a[0]->type==DVAL_LIST){items=a[0]->as.list.items;n=a[0]->as.list.count;}
    else{items=a;n=c;}
    if(n==0) return make_error("mn() empty");
    DuckValue *best=items[0];
    for(int i=1;i<n;i++){DuckValue*cmp=val_cmp(items[i],best,DTOK_LT);if(val_truthy(cmp))best=items[i];value_free(cmp);}
    best->ref_count++; return best;
}
static DuckValue *b_sum(DuckValue**a,int c){
    if(c!=1||a[0]->type!=DVAL_LIST) return make_error("sm() needs list");
    double t=0; int hf=0;
    for(int i=0;i<a[0]->as.list.count;i++){
        DuckValue *v=a[0]->as.list.items[i];
        if(v->type==DVAL_FLOAT){t+=v->as.fval;hf=1;} else if(v->type==DVAL_INT) t+=v->as.ival;
    }
    return hf?make_float(t):make_int((long long)t);
}
static DuckValue *b_sqr(DuckValue**a,int c){ if(c!=1)return make_error("sqr() takes 1");
    double v=(a[0]->type==DVAL_INT)?(double)a[0]->as.ival:a[0]->as.fval; return make_float(sqrt(v)); }
static DuckValue *b_flr(DuckValue**a,int c){ if(c!=1)return make_error("flr() takes 1");
    double v=(a[0]->type==DVAL_INT)?(double)a[0]->as.ival:a[0]->as.fval; return make_int((long long)floor(v)); }
static DuckValue *b_cil(DuckValue**a,int c){ if(c!=1)return make_error("cil() takes 1");
    double v=(a[0]->type==DVAL_INT)?(double)a[0]->as.ival:a[0]->as.fval; return make_int((long long)ceil(v)); }
static DuckValue *b_rnd(DuckValue**a,int c){
    if(c<1) return make_error("rnd() takes 1-2 args");
    double v=(a[0]->type==DVAL_INT)?(double)a[0]->as.ival:a[0]->as.fval;
    if(c==2){ double f=pow(10,(int)a[1]->as.ival); return make_float(round(v*f)/f); }
    return make_int((long long)round(v));
}

/* ── String methods ── */
static DuckValue *str_method(DuckValue *obj, const char *m, DuckValue **a, int c){
    if(strcmp(m,"uppr")==0||strcmp(m,"upper")==0){
        char *s=strdup(obj->as.sval); for(int i=0;s[i];i++) s[i]=toupper((unsigned char)s[i]);
        DuckValue *r=make_string(s); free(s); return r; }
    if(strcmp(m,"lwr")==0||strcmp(m,"lower")==0){
        char *s=strdup(obj->as.sval); for(int i=0;s[i];i++) s[i]=tolower((unsigned char)s[i]);
        DuckValue *r=make_string(s); free(s); return r; }
    if(strcmp(m,"strp")==0||strcmp(m,"strip")==0){
        char *s=strdup(obj->as.sval); int a2=0,e=(int)strlen(s)-1;
        while(a2<=e&&isspace((unsigned char)s[a2]))a2++;
        while(e>a2&&isspace((unsigned char)s[e]))e--;
        s[e+1]='\0'; DuckValue *r=make_string(s+a2); free(s); return r; }
    if(strcmp(m,"len")==0) return make_int(strlen(obj->as.sval));
    if(strcmp(m,"splt")==0||strcmp(m,"split")==0){
        const char *d=(c>=1&&a[0]->type==DVAL_STRING)?a[0]->as.sval:" ";
        DuckValue *lst=make_list(); char *s=strdup(obj->as.sval);
        char *tok=strtok(s,d); while(tok){list_push(lst,make_string(tok));tok=strtok(NULL,d);}
        free(s); return lst; }
    if(strcmp(m,"rpl")==0||strcmp(m,"replace")==0){
        if(c<2) return make_error("rpl() needs 2 args");
        const char *fr=a[0]->as.sval, *to=a[1]->as.sval;
        char *s=obj->as.sval; char buf[MAX_STR]; int bi=0; int fl=strlen(fr);
        while(*s){ if(strncmp(s,fr,fl)==0){for(int i=0;to[i]&&bi<MAX_STR-1;i++) buf[bi++]=to[i];s+=fl;}
                   else buf[bi++]=*s++; }
        buf[bi]='\0'; return make_string(buf); }
    if(strcmp(m,"fnd")==0||strcmp(m,"find")==0){
        if(c<1) return make_error("fnd() needs 1 arg");
        char *p=strstr(obj->as.sval,a[0]->as.sval);
        return make_int(p?(long long)(p-obj->as.sval):-1); }
    if(strcmp(m,"startswith")==0||strcmp(m,"strtswth")==0){
        if(c<1) return make_error("startswith() needs 1 arg");
        return make_bool(strncmp(obj->as.sval,a[0]->as.sval,strlen(a[0]->as.sval))==0); }
    if(strcmp(m,"endswith")==0){
        if(c<1) return make_error("endswith() needs 1 arg");
        size_t sl=strlen(obj->as.sval),el=strlen(a[0]->as.sval);
        return make_bool(sl>=el&&strcmp(obj->as.sval+sl-el,a[0]->as.sval)==0); }
    return make_error("Unknown string method '%s'",m);
}

/* ── List methods ── */
static DuckValue *lst_method(DuckValue *obj, const char *m, DuckValue **a, int c){
    if(strcmp(m,"app")==0||strcmp(m,"append")==0){
        if(c!=1) return make_error("app() takes 1 arg");
        a[0]->ref_count++; list_push(obj,a[0]); return make_null(); }
    if(strcmp(m,"pop")==0){
        if(obj->as.list.count==0) return make_error("pop() empty list");
        int idx=(c>=1)?(int)a[0]->as.ival:obj->as.list.count-1;
        DuckValue *v=obj->as.list.items[idx];
        for(int i=idx;i<obj->as.list.count-1;i++) obj->as.list.items[i]=obj->as.list.items[i+1];
        obj->as.list.count--; return v; }
    if(strcmp(m,"len")==0) return make_int(obj->as.list.count);
    if(strcmp(m,"srt")==0||strcmp(m,"sort")==0){
        for(int i=0;i<obj->as.list.count-1;i++)
            for(int j=0;j<obj->as.list.count-1-i;j++){
                DuckValue*cmp=val_cmp(obj->as.list.items[j],obj->as.list.items[j+1],DTOK_GT);
                if(val_truthy(cmp)){DuckValue*t=obj->as.list.items[j];obj->as.list.items[j]=obj->as.list.items[j+1];obj->as.list.items[j+1]=t;}
                value_free(cmp); }
        return make_null(); }
    if(strcmp(m,"rvs")==0||strcmp(m,"reverse")==0){
        int n=obj->as.list.count;
        for(int i=0;i<n/2;i++){DuckValue*t=obj->as.list.items[i];obj->as.list.items[i]=obj->as.list.items[n-1-i];obj->as.list.items[n-1-i]=t;}
        return make_null(); }
    if(strcmp(m,"jn")==0||strcmp(m,"join")==0){
        const char *sep=(c>=1)?a[0]->as.sval:"";
        char buf[MAX_STR]; buf[0]='\0';
        for(int i=0;i<obj->as.list.count;i++){
            if(i>0) strncat(buf,sep,MAX_STR-strlen(buf)-1);
            char *s=val_to_str(obj->as.list.items[i]);
            strncat(buf,s,MAX_STR-strlen(buf)-1); free(s); }
        return make_string(buf); }
    return make_error("Unknown list method '%s'",m);
}

/* ── Dict methods ── */
static DuckValue *dct_method(DuckValue *obj, const char *m, DuckValue **a, int c){
    if(strcmp(m,"ks")==0||strcmp(m,"keys")==0){
        DuckValue *lst=make_list();
        for(int i=0;i<obj->as.dict.count;i++) list_push(lst,make_string(obj->as.dict.keys[i]));
        return lst; }
    if(strcmp(m,"vls")==0||strcmp(m,"values")==0){
        DuckValue *lst=make_list();
        for(int i=0;i<obj->as.dict.count;i++){obj->as.dict.vals[i]->ref_count++;list_push(lst,obj->as.dict.vals[i]);}
        return lst; }
    if(strcmp(m,"gt")==0||strcmp(m,"get")==0){
        if(c<1) return make_error("gt() needs 1 arg");
        for(int i=0;i<obj->as.dict.count;i++)
            if(strcmp(obj->as.dict.keys[i],a[0]->as.sval)==0){obj->as.dict.vals[i]->ref_count++;return obj->as.dict.vals[i];}
        if(c>=2){a[1]->ref_count++;return a[1];} return make_null(); }
    return make_error("Unknown dict method '%s'",m);
}

static DuckValue *call_method(DuckInterp *ip, DuckValue *obj, const char *m, DuckValue **a, int c){
    if(obj->type==DVAL_STRING) return str_method(obj,m,a,c);
    if(obj->type==DVAL_LIST)   return lst_method(obj,m,a,c);
    if(obj->type==DVAL_DICT)   return dct_method(obj,m,a,c);
    return make_error("Unknown method '%s'",m);
}

static DuckValue *call_fn(DuckInterp *ip, DuckValue *fn, DuckValue **args, int argc, DuckEnv *env){
    if(fn->type!=DVAL_FUNCTION){duck_error(ip,0,"Not a function");return make_null();}
    if(argc!=fn->as.func.param_count){
        duck_error(ip,0,"'%s' expects %d args got %d",
            fn->as.func.name?fn->as.func.name:"?",fn->as.func.param_count,argc);
        return make_null();
    }
    DuckEnv *fenv=env_new(fn->as.func.closure?fn->as.func.closure:env);
    for(int i=0;i<argc;i++) env_set(fenv,fn->as.func.params[i],args[i]);
    dexec_block(ip,fn->as.func.body,fenv);
    DuckValue *ret=make_null();
    if(ip->returning){
        ip->returning=0;
        if(ip->return_value){value_free(ret);ret=ip->return_value;ip->return_value=NULL;}
    }
    env_free(fenv); return ret;
}

/* ── prn formatting ──
   Produces clean output with:
   - Proper spacing between items
   - No trailing space before newline
   - sep/end support
   - qk prepends duck emoji
*/
static void do_print(DuckInterp *ip, DuckNode *node, DuckEnv *env){
    DUCK_SET_UTF8();
    if(node->as.print.is_qk) printf("\xF0\x9F\xA6\x86 ");
    const char *sep = node->as.print.sep ? node->as.print.sep : " ";
    const char *end = node->as.print.end ? node->as.print.end : "\n";
    for(int i=0;i<node->as.print.argc;i++){
        if(i>0) printf("%s",sep);
        DuckValue *v=deval(ip,node->as.print.args[i],env);
        if(ip->had_error){value_free(v);return;}
        char *s=val_to_str(v);
        printf("%s",s);
        free(s); value_free(v);
    }
    printf("%s",end);
    fflush(stdout);
}

static DuckValue *deval(DuckInterp *ip, DuckNode *node, DuckEnv *env){
    if(!node||ip->had_error) return make_null();
    switch(node->type){
        case DNODE_INT_LIT:   return make_int(node->as.int_lit.val);
        case DNODE_FLOAT_LIT: return make_float(node->as.flt_lit.val);
        case DNODE_STR_LIT:   return make_string(node->as.str_lit.val);
        case DNODE_BOOL_LIT:  return make_bool(node->as.bool_lit.val);
        case DNODE_NULL_LIT:  return make_null();
        case DNODE_IDENT: {
            const char *nm=node->as.ident.name;
            if(strcmp(nm,"pi")==0)  return make_float(3.14159265358979323846);
            if(strcmp(nm,"inf")==0) return make_float(1.0/0.0);
            if(strcmp(nm,"e_")==0)  return make_float(2.71828182845904523536);
            DuckValue *v=env_get(env,nm);
            if(!v){duck_error(ip,node->line,"Undefined: '%s'",nm);return make_null();}
            v->ref_count++; return v;
        }
        case DNODE_ASSIGN: {
            DuckValue *val=deval(ip,node->as.assign.value,env);
            if(!ip->had_error) env_set(env,node->as.assign.target,val);
            value_free(val); return make_null();
        }
        case DNODE_AUG_ASSIGN: {
            DuckValue *cur=env_get(env,node->as.assign.target);
            if(!cur){duck_error(ip,node->line,"Undefined: '%s'",node->as.assign.target);return make_null();}
            DuckValue *rhs=deval(ip,node->as.assign.value,env);
            DuckValue *res=NULL;
            double ca=(cur->type==DVAL_INT)?(double)cur->as.ival:cur->as.fval;
            double rb=(rhs->type==DVAL_INT)?(double)rhs->as.ival:rhs->as.fval;
            int both_int=(cur->type==DVAL_INT&&rhs->type==DVAL_INT);
            switch(node->as.assign.op){
                case DTOK_PLUS_EQ:  res=val_add(cur,rhs); break;
                case DTOK_MINUS_EQ: res=both_int?make_int(cur->as.ival-rhs->as.ival):make_float(ca-rb); break;
                case DTOK_STAR_EQ:  res=both_int?make_int(cur->as.ival*rhs->as.ival):make_float(ca*rb); break;
                case DTOK_SLASH_EQ:
                    if(rb==0){duck_error(ip,node->line,"Division by zero");res=make_null();}
                    else res=make_float(ca/rb); break;
                default: res=make_null();
            }
            value_free(rhs); env_update(env,node->as.assign.target,res); value_free(res); return make_null();
        }
        case DNODE_BINARY: {
            /* Short circuit */
            if(node->as.binary.op==DTOK_ND){
                DuckValue *l=deval(ip,node->as.binary.left,env);
                if(!val_truthy(l)) return l;
                value_free(l); return deval(ip,node->as.binary.right,env);
            }
            if(node->as.binary.op==DTOK_OR){
                DuckValue *l=deval(ip,node->as.binary.left,env);
                if(val_truthy(l)) return l;
                value_free(l); return deval(ip,node->as.binary.right,env);
            }
            DuckValue *l=deval(ip,node->as.binary.left,env);
            if(ip->had_error) return l;
            DuckValue *r=deval(ip,node->as.binary.right,env);
            if(ip->had_error){value_free(l);return r;}
            DuckTokType op=node->as.binary.op;
            DuckValue *res=NULL;
            if(op==DTOK_EQ||op==DTOK_NEQ||op==DTOK_LT||op==DTOK_LE||op==DTOK_GT||op==DTOK_GE)
                res=val_cmp(l,r,op);
            else if(op==DTOK_PLUS) res=val_add(l,r);
            else if(op==DTOK_MINUS){
                double la=(l->type==DVAL_INT)?(double)l->as.ival:l->as.fval;
                double rb=(r->type==DVAL_INT)?(double)r->as.ival:r->as.fval;
                res=(l->type==DVAL_INT&&r->type==DVAL_INT)?make_int(l->as.ival-r->as.ival):make_float(la-rb);
            }
            else if(op==DTOK_STAR){
                if(l->type==DVAL_INT&&r->type==DVAL_INT) res=make_int(l->as.ival*r->as.ival);
                else if(l->type==DVAL_STRING&&r->type==DVAL_INT){
                    int n=(int)r->as.ival, sl=strlen(l->as.sval);
                    char *buf=calloc(sl*n+1,1);
                    for(int i=0;i<n;i++) strcat(buf,l->as.sval);
                    res=make_string(buf); free(buf);
                } else {
                    double la=(l->type==DVAL_INT)?(double)l->as.ival:l->as.fval;
                    double rb=(r->type==DVAL_INT)?(double)r->as.ival:r->as.fval;
                    res=make_float(la*rb);
                }
            }
            else if(op==DTOK_SLASH){
                double la=(l->type==DVAL_INT)?(double)l->as.ival:l->as.fval;
                double rb=(r->type==DVAL_INT)?(double)r->as.ival:r->as.fval;
                if(rb==0){duck_error(ip,node->line,"Division by zero");res=make_null();}
                else res=make_float(la/rb);
            }
            else if(op==DTOK_PERCENT){
                if(l->type==DVAL_INT&&r->type==DVAL_INT) res=make_int(l->as.ival%r->as.ival);
                else{ double la=(l->type==DVAL_INT)?(double)l->as.ival:l->as.fval;
                      double rb=(r->type==DVAL_INT)?(double)r->as.ival:r->as.fval; res=make_float(fmod(la,rb)); }
            }
            else if(op==DTOK_DSTAR){
                double la=(l->type==DVAL_INT)?(double)l->as.ival:l->as.fval;
                double rb=(r->type==DVAL_INT)?(double)r->as.ival:r->as.fval;
                res=make_float(pow(la,rb));
            }
            else if(op==DTOK_IN){
                if(r->type==DVAL_LIST){
                    int found=0;
                    for(int i=0;i<r->as.list.count;i++){DuckValue*c=val_cmp(l,r->as.list.items[i],DTOK_EQ);if(val_truthy(c))found=1;value_free(c);if(found)break;}
                    res=make_bool(found);
                } else if(r->type==DVAL_STRING&&l->type==DVAL_STRING)
                    res=make_bool(strstr(r->as.sval,l->as.sval)!=NULL);
                else res=make_bool(0);
            }
            else res=make_null();
            value_free(l); value_free(r);
            return res?res:make_null();
        }
        case DNODE_UNARY: {
            DuckValue *v=deval(ip,node->as.unary.operand,env);
            if(node->as.unary.op==DTOK_NT) return make_bool(!val_truthy(v));
            if(node->as.unary.op==DTOK_MINUS){
                if(v->type==DVAL_INT){DuckValue*r=make_int(-v->as.ival);value_free(v);return r;}
                if(v->type==DVAL_FLOAT){DuckValue*r=make_float(-v->as.fval);value_free(v);return r;}
            }
            return v;
        }
        case DNODE_PRINT: do_print(ip,node,env); return make_null();
        case DNODE_INPUT: {
            DUCK_SET_UTF8();
            if(node->as.input.prompt){
                DuckValue *pv=deval(ip,node->as.input.prompt,env);
                char *ps=val_to_str(pv); printf("%s",ps); fflush(stdout); free(ps); value_free(pv);
            }
            char buf[MAX_STR];
            if(!fgets(buf,MAX_STR,stdin)) return make_string("");
            int len=strlen(buf); if(len>0&&buf[len-1]=='\n') buf[--len]='\0';
            DuckValue *rv=make_string(buf);
            if(node->as.input.target) env_set(env,node->as.input.target,rv);
            rv->ref_count++; value_free(rv); return rv;
        }
        case DNODE_IF: {
            DuckValue *cond=deval(ip,node->as.if_s.cond,env);
            int truth=val_truthy(cond); value_free(cond);
            if(truth) return dexec_block(ip,node->as.if_s.then_br,env);
            for(int i=0;i<node->as.if_s.elif_count;i++){
                DuckValue *ec=deval(ip,node->as.if_s.elif_conds[i],env);
                int et=val_truthy(ec); value_free(ec);
                if(et) return dexec_block(ip,node->as.if_s.elif_brs[i],env);
            }
            if(node->as.if_s.else_br) return dexec_block(ip,node->as.if_s.else_br,env);
            return make_null();
        }
        case DNODE_WHILE: {
            while(!ip->had_error){
                DuckValue *cond=deval(ip,node->as.while_s.cond,env);
                int truth=val_truthy(cond); value_free(cond);
                if(!truth) break;
                DuckValue *r=dexec_block(ip,node->as.while_s.body,env); value_free(r);
                if(ip->returning) break;
                if(ip->breaking){ip->breaking=0;break;}
                if(ip->continuing){ip->continuing=0;continue;}
            }
            return make_null();
        }
        case DNODE_FOR: {
            DuckValue *it=deval(ip,node->as.for_s.iterable,env);
            if(it->type!=DVAL_LIST){duck_error(ip,node->line,"'fr' needs list/range");value_free(it);return make_null();}
            for(int i=0;i<it->as.list.count&&!ip->had_error;i++){
                env_set(env,node->as.for_s.var,it->as.list.items[i]);
                DuckValue *r=dexec_block(ip,node->as.for_s.body,env); value_free(r);
                if(ip->returning) break;
                if(ip->breaking){ip->breaking=0;break;}
                if(ip->continuing){ip->continuing=0;continue;}
            }
            value_free(it); return make_null();
        }
        case DNODE_FUNC_DEF: {
            DuckValue *fn=calloc(1,sizeof*fn);
            fn->type=DVAL_FUNCTION; fn->ref_count=1;
            fn->as.func.name=strdup(node->as.func_def.name);
            fn->as.func.param_count=node->as.func_def.param_count;
            fn->as.func.params=malloc(fn->as.func.param_count*sizeof(char*));
            for(int i=0;i<fn->as.func.param_count;i++) fn->as.func.params[i]=strdup(node->as.func_def.params[i]);
            fn->as.func.body=node->as.func_def.body; fn->as.func.closure=env;
            env_set(env,node->as.func_def.name,fn); value_free(fn); return make_null();
        }
        case DNODE_RETURN: {
            DuckValue *v=node->as.ret.value?deval(ip,node->as.ret.value,env):make_null();
            ip->returning=1; ip->return_value=v; v->ref_count++; return v;
        }
        case DNODE_BREAK:    ip->breaking=1;    return make_null();
        case DNODE_CONTINUE: ip->continuing=1;  return make_null();
        case DNODE_PASS:                         return make_null();
        case DNODE_CALL: {
            DuckValue *args[MAX_ARGS]={0}; int argc=node->as.call.argc;
            for(int i=0;i<argc;i++) args[i]=deval(ip,node->as.call.args[i],env);
            if(ip->had_error) goto cc;
            /* Method call */
            if(node->as.call.callee->type==DNODE_ATTR){
                DuckValue *obj=deval(ip,node->as.call.callee->as.attr.obj,env);
                const char *m=node->as.call.callee->as.attr.attr;
                DuckValue *res=call_method(ip,obj,m,args,argc);
                value_free(obj); for(int i=0;i<argc;i++) value_free(args[i]); return res;
            }
            /* Named call */
            if(node->as.call.callee->type==DNODE_IDENT){
                const char *fn=node->as.call.callee->as.ident.name;
                DuckValue *res=NULL;
                if(strcmp(fn,"len")==0)  res=b_len(args,argc);
                else if(strcmp(fn,"rng")==0)  res=b_rng(args,argc);
                else if(strcmp(fn,"str")==0)  res=b_str(args,argc);
                else if(strcmp(fn,"int")==0)  res=b_int(args,argc);
                else if(strcmp(fn,"flt")==0)  res=b_flt(args,argc);
                else if(strcmp(fn,"typ")==0)  res=b_typ(args,argc);
                else if(strcmp(fn,"abs")==0)  res=b_abs(args,argc);
                else if(strcmp(fn,"mx")==0)   res=b_max(args,argc);
                else if(strcmp(fn,"mn")==0)   res=b_min(args,argc);
                else if(strcmp(fn,"sm")==0)   res=b_sum(args,argc);
                else if(strcmp(fn,"sqr")==0)  res=b_sqr(args,argc);
                else if(strcmp(fn,"flr")==0)  res=b_flr(args,argc);
                else if(strcmp(fn,"cil")==0)  res=b_cil(args,argc);
                else if(strcmp(fn,"rnd")==0)  res=b_rnd(args,argc);
                else if(strcmp(fn,"rndi")==0||strcmp(fn,"randint")==0){
                    if(argc<2){duck_error(ip,node->line,"rndi() needs 2 args");res=make_null();}
                    else res=make_int(args[0]->as.ival+rand()%(args[1]->as.ival-args[0]->as.ival+1));
                }
                else if(strcmp(fn,"inp")==0){
                    DUCK_SET_UTF8();
                    if(argc>=1){char*ps=val_to_str(args[0]);printf("%s",ps);fflush(stdout);free(ps);}
                    char buf[MAX_STR];
                    if(!fgets(buf,MAX_STR,stdin)) res=make_string("");
                    else{int ln2=strlen(buf);if(ln2>0&&buf[ln2-1]=='\n')buf[--ln2]='\0';res=make_string(buf);}
                }
                else {
                    DuckValue *fv=env_get(env,fn);
                    if(!fv){duck_error(ip,node->line,"Undefined: '%s'",fn);goto cc;}
                    res=call_fn(ip,fv,args,argc,env);
                }
                for(int i=0;i<argc;i++) value_free(args[i]);
                return res?res:make_null();
            }
            /* generic callee */
            { DuckValue *fv=deval(ip,node->as.call.callee,env);
              DuckValue *res=call_fn(ip,fv,args,argc,env);
              value_free(fv); for(int i=0;i<argc;i++) value_free(args[i]); return res; }
            cc: for(int i=0;i<argc;i++) value_free(args[i]); return make_null();
        }
        case DNODE_ATTR: {
            /* standalone attribute read (pi etc.) */
            DuckValue *obj=deval(ip,node->as.attr.obj,env);
            value_free(obj); return make_null();
        }
        case DNODE_SUBSCRIPT: {
            DuckValue *obj=deval(ip,node->as.sub.obj,env);
            DuckValue *idx=deval(ip,node->as.sub.index,env);
            DuckValue *res=make_null();
            if(obj->type==DVAL_LIST){
                long long i=idx->as.ival; if(i<0)i+=obj->as.list.count;
                if(i>=0&&i<obj->as.list.count){res=obj->as.list.items[i];res->ref_count++;}
                else duck_error(ip,node->line,"Index out of range");
            } else if(obj->type==DVAL_STRING){
                int i=(int)idx->as.ival; char ch[2]={obj->as.sval[i],'\0'}; res=make_string(ch);
            } else if(obj->type==DVAL_DICT){
                char *key=val_to_str(idx);
                for(int i=0;i<obj->as.dict.count;i++)
                    if(strcmp(obj->as.dict.keys[i],key)==0){res=obj->as.dict.vals[i];res->ref_count++;break;}
                free(key);
            }
            value_free(obj); value_free(idx); return res;
        }
        case DNODE_LIST_LIT: {
            DuckValue *lst=make_list();
            for(int i=0;i<node->as.list_lit.count;i++){
                DuckValue *item=deval(ip,node->as.list_lit.items[i],env);
                if(ip->had_error){value_free(lst);return item;}
                list_push(lst,item);
            }
            return lst;
        }
        case DNODE_DICT_LIT: {
            DuckValue *d=calloc(1,sizeof*d); d->type=DVAL_DICT; d->ref_count=1;
            d->as.dict.count=node->as.dict_lit.count;
            d->as.dict.keys=calloc(d->as.dict.count,sizeof(char*));
            d->as.dict.vals=calloc(d->as.dict.count,sizeof(DuckValue*));
            for(int i=0;i<d->as.dict.count;i++){
                DuckValue *k=deval(ip,node->as.dict_lit.keys[i],env);
                DuckValue *v=deval(ip,node->as.dict_lit.vals[i],env);
                d->as.dict.keys[i]=val_to_str(k); d->as.dict.vals[i]=v; value_free(k);
            }
            return d;
        }
        case DNODE_TRY: {
            dexec_block(ip,node->as.try_s.body,env);
            if(ip->had_error&&node->as.try_s.catch_body){
                ip->had_error=0;
                if(node->as.try_s.exc_var) env_set(env,node->as.try_s.exc_var,make_string(ip->error_msg));
                dexec_block(ip,node->as.try_s.catch_body,env);
            }
            if(node->as.try_s.finally_body) dexec_block(ip,node->as.try_s.finally_body,env);
            return make_null();
        }
        default: return make_null();
    }
}

static DuckValue *dexec_block(DuckInterp *ip, DuckNode *blk, DuckEnv *env){
    if(!blk) return make_null();
    DuckValue *last=make_null();
    for(int i=0;i<blk->as.block.count;i++){
        if(ip->had_error||ip->returning||ip->breaking||ip->continuing) break;
        value_free(last);
        last=deval(ip,blk->as.block.stmts[i],env);
    }
    return last;
}

DuckValue *interp_run(DuckInterp *ip, DuckNode *prog){
    srand((unsigned)time(NULL));
    return dexec_block(ip,prog,ip->global_env);
}
