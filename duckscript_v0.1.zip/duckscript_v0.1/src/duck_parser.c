/*
 * duck_parser.c — DuckScript v0.1 Parser
 */
#include "duck.h"

typedef struct { DuckToken *tokens; int count, pos; } Parser;

static DuckToken *ptok(Parser *p)   { return &p->tokens[p->pos]; }
static DuckToken *pprev(Parser *p)  { return &p->tokens[p->pos-1]; }
static int pat_end(Parser *p)       { return ptok(p)->type==DTOK_EOF; }
static DuckToken *padv(Parser *p)   { if(!pat_end(p)) p->pos++; return pprev(p); }
static int pcheck(Parser *p, DuckTokType t) { return ptok(p)->type==t; }
static int pmatch(Parser *p, DuckTokType t) { if(pcheck(p,t)){padv(p);return 1;} return 0; }
static void pexpect(Parser *p, DuckTokType t, const char *msg){
    if(pcheck(p,t)){padv(p);return;}
    fprintf(stderr,"\n[DuckScript ParseError] Line %d: Expected %s, got '%s'\n",
        ptok(p)->line,msg,ptok(p)->lexeme); exit(1);
}
static void pnl(Parser *p){ while(pcheck(p,DTOK_NEWLINE)) padv(p); }

static DuckNode *nnode(DuckNodeType t, int line){
    DuckNode *n=calloc(1,sizeof*n); n->type=t; n->line=line; return n;
}

/* Forward decls */
static DuckNode *pexpr(Parser *p);
static DuckNode *pstmt(Parser *p);
static DuckNode *pblock(Parser *p);

static DuckNode *pprimary(Parser *p){
    int ln=ptok(p)->line;
    if(pmatch(p,DTOK_INT))   {DuckNode*n=nnode(DNODE_INT_LIT,ln);  n->as.int_lit.val=pprev(p)->lit.ival;return n;}
    if(pmatch(p,DTOK_FLOAT)) {DuckNode*n=nnode(DNODE_FLOAT_LIT,ln);n->as.flt_lit.val=pprev(p)->lit.fval;return n;}
    if(pmatch(p,DTOK_STRING)){DuckNode*n=nnode(DNODE_STR_LIT,ln);  n->as.str_lit.val=strdup(pprev(p)->lexeme);return n;}
    if(pmatch(p,DTOK_BOOL))  {DuckNode*n=nnode(DNODE_BOOL_LIT,ln); n->as.bool_lit.val=pprev(p)->lit.bval;return n;}
    if(pmatch(p,DTOK_NULL))  {return nnode(DNODE_NULL_LIT,ln);}
    if(pmatch(p,DTOK_LBRACKET)){
        DuckNode *n=nnode(DNODE_LIST_LIT,ln);
        DuckNode **items=malloc(MAX_ARGS*sizeof(DuckNode*)); int cnt=0;
        pnl(p);
        while(!pcheck(p,DTOK_RBRACKET)&&!pat_end(p)){
            items[cnt++]=pexpr(p); pnl(p); if(!pmatch(p,DTOK_COMMA)) break; pnl(p);
        }
        pexpect(p,DTOK_RBRACKET,"]");
        n->as.list_lit.items=items; n->as.list_lit.count=cnt; return n;
    }
    if(pmatch(p,DTOK_LBRACE)){
        DuckNode *n=nnode(DNODE_DICT_LIT,ln);
        DuckNode **ks=malloc(MAX_ARGS*sizeof(DuckNode*));
        DuckNode **vs=malloc(MAX_ARGS*sizeof(DuckNode*)); int cnt=0;
        pnl(p);
        while(!pcheck(p,DTOK_RBRACE)&&!pat_end(p)){
            ks[cnt]=pexpr(p); pexpect(p,DTOK_COLON,":"); vs[cnt]=pexpr(p); cnt++;
            pnl(p); if(!pmatch(p,DTOK_COMMA)) break; pnl(p);
        }
        pexpect(p,DTOK_RBRACE,"}");
        n->as.dict_lit.keys=ks; n->as.dict_lit.vals=vs; n->as.dict_lit.count=cnt; return n;
    }
    if(pmatch(p,DTOK_LPAREN)){DuckNode*inner=pexpr(p);pexpect(p,DTOK_RPAREN,")");return inner;}
    if(pcheck(p,DTOK_IDENT)){
        padv(p);
        DuckNode *n=nnode(DNODE_IDENT,ln); n->as.ident.name=strdup(pprev(p)->lexeme); return n;
    }
    fprintf(stderr,"\n[DuckScript ParseError] Line %d: Unexpected token '%s'\n",ln,ptok(p)->lexeme);
    exit(1);
}

static DuckNode *pcall_attr(Parser *p){
    DuckNode *expr=pprimary(p);
    while(1){
        int ln=ptok(p)->line;
        if(pmatch(p,DTOK_LPAREN)){
            DuckNode *call=nnode(DNODE_CALL,ln);
            call->as.call.callee=expr;
            DuckNode **args=malloc(MAX_ARGS*sizeof(DuckNode*)); int ac=0;
            while(!pcheck(p,DTOK_RPAREN)&&!pat_end(p)){
                args[ac++]=pexpr(p); if(!pmatch(p,DTOK_COMMA)) break;
            }
            pexpect(p,DTOK_RPAREN,")");
            call->as.call.args=args; call->as.call.argc=ac; expr=call;
        } else if(pmatch(p,DTOK_DOT)){
            DuckNode *at=nnode(DNODE_ATTR,ln);
            at->as.attr.obj=expr;
            DuckToken *attr=&p->tokens[p->pos]; padv(p);
            at->as.attr.attr=strdup(attr->lexeme); expr=at;
        } else if(pmatch(p,DTOK_LBRACKET)){
            DuckNode *idx=pexpr(p); pexpect(p,DTOK_RBRACKET,"]");
            DuckNode *sub=nnode(DNODE_SUBSCRIPT,ln);
            sub->as.sub.obj=expr; sub->as.sub.index=idx; expr=sub;
        } else break;
    }
    return expr;
}

static DuckNode *punary(Parser *p){
    int ln=ptok(p)->line;
    if(pmatch(p,DTOK_NT)||pmatch(p,DTOK_MINUS)){
        DuckTokType op=pprev(p)->type;
        DuckNode *n=nnode(DNODE_UNARY,ln); n->as.unary.op=op; n->as.unary.operand=punary(p); return n;
    }
    return pcall_attr(p);
}

static DuckNode *ppow(Parser *p){
    DuckNode *l=punary(p);
    while(pcheck(p,DTOK_DSTAR)){int ln=ptok(p)->line;padv(p);
        DuckNode *n=nnode(DNODE_BINARY,ln);n->as.binary.op=DTOK_DSTAR;n->as.binary.left=l;n->as.binary.right=punary(p);l=n;}
    return l;
}
static DuckNode *pmul(Parser *p){
    DuckNode *l=ppow(p);
    while(pcheck(p,DTOK_STAR)||pcheck(p,DTOK_SLASH)||pcheck(p,DTOK_PERCENT)){
        int ln=ptok(p)->line; DuckTokType op=ptok(p)->type; padv(p);
        DuckNode *n=nnode(DNODE_BINARY,ln);n->as.binary.op=op;n->as.binary.left=l;n->as.binary.right=ppow(p);l=n;}
    return l;
}
static DuckNode *padd(Parser *p){
    DuckNode *l=pmul(p);
    while(pcheck(p,DTOK_PLUS)||pcheck(p,DTOK_MINUS)){
        int ln=ptok(p)->line; DuckTokType op=ptok(p)->type; padv(p);
        DuckNode *n=nnode(DNODE_BINARY,ln);n->as.binary.op=op;n->as.binary.left=l;n->as.binary.right=pmul(p);l=n;}
    return l;
}
static DuckNode *pcmp(Parser *p){
    DuckNode *l=padd(p);
    while(pcheck(p,DTOK_LT)||pcheck(p,DTOK_LE)||pcheck(p,DTOK_GT)||pcheck(p,DTOK_GE)||
          pcheck(p,DTOK_EQ)||pcheck(p,DTOK_NEQ)||pcheck(p,DTOK_IN)||pcheck(p,DTOK_IS)){
        int ln=ptok(p)->line; DuckTokType op=ptok(p)->type; padv(p);
        DuckNode *n=nnode(DNODE_BINARY,ln);n->as.binary.op=op;n->as.binary.left=l;n->as.binary.right=padd(p);l=n;}
    return l;
}
static DuckNode *plogic(Parser *p){
    DuckNode *l=pcmp(p);
    while(pcheck(p,DTOK_ND)||pcheck(p,DTOK_OR)){
        int ln=ptok(p)->line; DuckTokType op=ptok(p)->type; padv(p);
        DuckNode *n=nnode(DNODE_BINARY,ln);n->as.binary.op=op;n->as.binary.left=l;n->as.binary.right=pcmp(p);l=n;}
    return l;
}
static DuckNode *pexpr(Parser *p){ return plogic(p); }

static DuckNode *pprint(Parser *p, int is_qk){
    int ln=ptok(p)->line;
    DuckNode *n=nnode(DNODE_PRINT,ln);
    n->as.print.is_qk=is_qk; n->as.print.sep=NULL; n->as.print.end=NULL;
    if(!pmatch(p,DTOK_LPAREN)){
        DuckNode **args=malloc(MAX_ARGS*sizeof(DuckNode*)); int ac=0;
        while(!pcheck(p,DTOK_NEWLINE)&&!pat_end(p)) args[ac++]=pexpr(p);
        n->as.print.args=args; n->as.print.argc=ac; return n;
    }
    DuckNode **args=malloc(MAX_ARGS*sizeof(DuckNode*)); int ac=0;
    while(!pcheck(p,DTOK_RPAREN)&&!pat_end(p)){
        if(pcheck(p,DTOK_IDENT)&&p->tokens[p->pos+1].type==DTOK_ASSIGN){
            char kw[32]; strncpy(kw,ptok(p)->lexeme,31); padv(p); padv(p);
            DuckNode *val=pexpr(p);
            if(val->type==DNODE_STR_LIT){
                if(strcmp(kw,"end")==0) n->as.print.end=val->as.str_lit.val;
                if(strcmp(kw,"sep")==0) n->as.print.sep=val->as.str_lit.val;
            }
            pmatch(p,DTOK_COMMA); continue;
        }
        args[ac++]=pexpr(p); if(!pmatch(p,DTOK_COMMA)) break;
    }
    pexpect(p,DTOK_RPAREN,")");
    n->as.print.args=args; n->as.print.argc=ac; return n;
}

static DuckNode *pif(Parser *p){
    int ln=ptok(p)->line;
    DuckNode *n=nnode(DNODE_IF,ln);
    n->as.if_s.cond=pexpr(p); pexpect(p,DTOK_COLON,":"); pmatch(p,DTOK_NEWLINE);
    n->as.if_s.then_br=pblock(p);
    n->as.if_s.elif_count=0;
    n->as.if_s.elif_conds=malloc(16*sizeof(DuckNode*));
    n->as.if_s.elif_brs=malloc(16*sizeof(DuckNode*));
    n->as.if_s.else_br=NULL;
    while(pcheck(p,DTOK_ELIF)){
        padv(p); int ei=n->as.if_s.elif_count++;
        n->as.if_s.elif_conds[ei]=pexpr(p);
        pexpect(p,DTOK_COLON,":"); pmatch(p,DTOK_NEWLINE);
        n->as.if_s.elif_brs[ei]=pblock(p);
    }
    if(pmatch(p,DTOK_ELS)){
        pexpect(p,DTOK_COLON,":"); pmatch(p,DTOK_NEWLINE);
        n->as.if_s.else_br=pblock(p);
    }
    return n;
}

static DuckNode *pwhile(Parser *p){
    int ln=ptok(p)->line; DuckNode *n=nnode(DNODE_WHILE,ln);
    n->as.while_s.cond=pexpr(p); pexpect(p,DTOK_COLON,":"); pmatch(p,DTOK_NEWLINE);
    n->as.while_s.body=pblock(p); return n;
}

static DuckNode *pfor(Parser *p){
    int ln=ptok(p)->line; DuckNode *n=nnode(DNODE_FOR,ln);
    DuckToken *var=&p->tokens[p->pos]; padv(p);
    n->as.for_s.var=strdup(var->lexeme);
    if(!pmatch(p,DTOK_IN)){fprintf(stderr,"[DuckScript] Expected 'in' in fr loop\n");exit(1);}
    n->as.for_s.iterable=pexpr(p);
    pexpect(p,DTOK_COLON,":"); pmatch(p,DTOK_NEWLINE);
    n->as.for_s.body=pblock(p); return n;
}

static DuckNode *pfuncdef(Parser *p){
    int ln=ptok(p)->line; DuckNode *n=nnode(DNODE_FUNC_DEF,ln);
    DuckToken *name=&p->tokens[p->pos]; padv(p);
    n->as.func_def.name=strdup(name->lexeme);
    pexpect(p,DTOK_LPAREN,"(");
    char **params=malloc(MAX_PARAMS*sizeof(char*)); int pc=0;
    while(!pcheck(p,DTOK_RPAREN)&&!pat_end(p)){
        params[pc++]=strdup(ptok(p)->lexeme); padv(p); if(!pmatch(p,DTOK_COMMA)) break;
    }
    pexpect(p,DTOK_RPAREN,")"); pmatch(p,DTOK_COLON); pmatch(p,DTOK_NEWLINE);
    n->as.func_def.params=params; n->as.func_def.param_count=pc;
    n->as.func_def.body=pblock(p); return n;
}

static DuckNode *ptry(Parser *p){
    int ln=ptok(p)->line; DuckNode *n=nnode(DNODE_TRY,ln);
    pexpect(p,DTOK_COLON,":"); pmatch(p,DTOK_NEWLINE); n->as.try_s.body=pblock(p);
    n->as.try_s.exc_type=n->as.try_s.exc_var=NULL;
    n->as.try_s.catch_body=n->as.try_s.finally_body=NULL;
    if(pmatch(p,DTOK_CTCH)){
        if(pcheck(p,DTOK_IDENT)){n->as.try_s.exc_type=strdup(ptok(p)->lexeme);padv(p);
            if(pmatch(p,DTOK_AS)){n->as.try_s.exc_var=strdup(ptok(p)->lexeme);padv(p);}}
        pexpect(p,DTOK_COLON,":"); pmatch(p,DTOK_NEWLINE); n->as.try_s.catch_body=pblock(p);
    }
    if(pmatch(p,DTOK_FNL)){pexpect(p,DTOK_COLON,":"); pmatch(p,DTOK_NEWLINE); n->as.try_s.finally_body=pblock(p);}
    return n;
}

static DuckNode *pblock(Parser *p){
    DuckNode *blk=nnode(DNODE_BLOCK,ptok(p)->line);
    DuckNode **stmts=malloc(1024*sizeof(DuckNode*)); int cnt=0;
    if(!pmatch(p,DTOK_INDENT)){stmts[cnt++]=pstmt(p);blk->as.block.stmts=stmts;blk->as.block.count=cnt;return blk;}
    while(!pcheck(p,DTOK_DEDENT)&&!pat_end(p)){pnl(p);if(pcheck(p,DTOK_DEDENT)||pat_end(p))break;stmts[cnt++]=pstmt(p);}
    pmatch(p,DTOK_DEDENT);
    blk->as.block.stmts=stmts; blk->as.block.count=cnt; return blk;
}

static DuckNode *pstmt(Parser *p){
    pnl(p); int ln=ptok(p)->line;
    if(pmatch(p,DTOK_PRN)) {DuckNode*n=pprint(p,0);pmatch(p,DTOK_NEWLINE);return n;}
    if(pmatch(p,DTOK_QK))  {DuckNode*n=pprint(p,1);pmatch(p,DTOK_NEWLINE);return n;}
    if(pmatch(p,DTOK_IFF)) return pif(p);
    if(pmatch(p,DTOK_WHL)) return pwhile(p);
    if(pmatch(p,DTOK_FR))  return pfor(p);
    if(pmatch(p,DTOK_FN))  return pfuncdef(p);
    if(pmatch(p,DTOK_TRY)) return ptry(p);
    if(pmatch(p,DTOK_RET)){
        DuckNode*n=nnode(DNODE_RETURN,ln);
        n->as.ret.value=(!pcheck(p,DTOK_NEWLINE)&&!pat_end(p))?pexpr(p):NULL;
        pmatch(p,DTOK_NEWLINE); return n;
    }
    if(pmatch(p,DTOK_BRK)) {pmatch(p,DTOK_NEWLINE);return nnode(DNODE_BREAK,ln);}
    if(pmatch(p,DTOK_CNT)) {pmatch(p,DTOK_NEWLINE);return nnode(DNODE_CONTINUE,ln);}
    if(pmatch(p,DTOK_PASS)){pmatch(p,DTOK_NEWLINE);return nnode(DNODE_PASS,ln);}
    DuckNode *expr=pexpr(p);
    if(pcheck(p,DTOK_PLUS_EQ)||pcheck(p,DTOK_MINUS_EQ)||pcheck(p,DTOK_STAR_EQ)||pcheck(p,DTOK_SLASH_EQ)){
        DuckTokType op=ptok(p)->type; padv(p); DuckNode*rhs=pexpr(p); pmatch(p,DTOK_NEWLINE);
        DuckNode*n=nnode(DNODE_AUG_ASSIGN,ln);
        n->as.assign.target=strdup(expr->as.ident.name); n->as.assign.value=rhs; n->as.assign.op=op; return n;
    }
    if(pmatch(p,DTOK_ASSIGN)){
        DuckNode*rhs=pexpr(p); pmatch(p,DTOK_NEWLINE);
        DuckNode*n=nnode(DNODE_ASSIGN,ln);
        n->as.assign.target=strdup(expr->as.ident.name); n->as.assign.value=rhs; return n;
    }
    pmatch(p,DTOK_NEWLINE); return expr;
}

DuckNode *duck_parse(DuckToken *tokens, int count){
    Parser p={tokens,count,0};
    DuckNode *prog=nnode(DNODE_BLOCK,0);
    DuckNode **stmts=malloc(4096*sizeof(DuckNode*)); int cnt=0;
    while(!pat_end(&p)){pnl(&p);if(pat_end(&p))break;stmts[cnt++]=pstmt(&p);}
    prog->as.block.stmts=stmts; prog->as.block.count=cnt; return prog;
}
