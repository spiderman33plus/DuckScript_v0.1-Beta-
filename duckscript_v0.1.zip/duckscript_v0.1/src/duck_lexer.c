/*
 * duck_lexer.c — DuckScript v0.1 Lexer
 */
#include "duck.h"

typedef struct { const char *kw; DuckTokType type; int bval; } KWEntry;

static KWEntry keywords[] = {
    {"prn",  DTOK_PRN,  0}, {"inp",  DTOK_INP,  0},
    {"qk",   DTOK_QK,   0}, {"iff",  DTOK_IFF,  0},
    {"elif", DTOK_ELIF, 0}, {"els",  DTOK_ELS,  0},
    {"whl",  DTOK_WHL,  0}, {"fr",   DTOK_FR,   0},
    {"brk",  DTOK_BRK,  0}, {"cnt",  DTOK_CNT,  0},
    {"fn",   DTOK_FN,   0}, {"ret",  DTOK_RET,  0},
    {"lmb",  DTOK_LMB,  0}, {"yld",  DTOK_YLD,  0},
    {"try",  DTOK_TRY,  0}, {"ctch", DTOK_CTCH, 0},
    {"fnl",  DTOK_FNL,  0}, {"rse",  DTOK_RSE,  0},
    {"imp",  DTOK_IMP,  0}, {"frm",  DTOK_FRM,  0},
    {"as",   DTOK_AS,   0}, {"glb",  DTOK_GLB,  0},
    {"pass", DTOK_PASS, 0},
    {"nd",   DTOK_ND,   0}, {"or",   DTOK_OR,   0},
    {"nt",   DTOK_NT,   0}, {"in",   DTOK_IN,   0},
    {"is",   DTOK_IS,   0},
    {"tru",  DTOK_BOOL, 1}, {"fls",  DTOK_BOOL, 0},
    {"nul",  DTOK_NULL, 0},
    {NULL, 0, 0}
};

typedef struct {
    const char *src;
    int pos, line;
    DuckToken *out;
    int out_count;
    int indent_stack[MAX_CALL_STACK];
    int indent_top;
} Lexer;

static void lex_err(Lexer *l, const char *msg) {
    fprintf(stderr, "\n[DuckScript Lexer Error] Line %d: %s\n", l->line, msg);
    exit(1);
}
static char lpeek(Lexer *l)           { return l->src[l->pos]; }
static char lpeek2(Lexer *l)          { return l->src[l->pos+1]; }
static char ladv(Lexer *l)            { char c=l->src[l->pos++]; if(c=='\n'){l->line++;} return c; }

static void emit(Lexer *l, DuckTokType t, const char *lex, long long iv, double fv, int bv) {
    DuckToken *tk = &l->out[l->out_count++];
    tk->type = t; tk->line = l->line;
    tk->lit.ival = iv; tk->lit.fval = fv; tk->lit.bval = bv;
    strncpy(tk->lexeme, lex, MAX_STR-1);
}

static void handle_indent(Lexer *l) {
    int sp = 0;
    while (lpeek(l)==' ') { sp++; ladv(l); }
    if (lpeek(l)=='\n'||lpeek(l)=='#'||lpeek(l)=='\0') return;
    int prev = l->indent_stack[l->indent_top];
    if (sp > prev) {
        l->indent_stack[++l->indent_top] = sp;
        emit(l, DTOK_INDENT, "INDENT", 0,0,0);
    } else {
        while (sp < l->indent_stack[l->indent_top]) {
            l->indent_top--;
            emit(l, DTOK_DEDENT, "DEDENT", 0,0,0);
        }
    }
}

static void lex_string(Lexer *l, char q) {
    ladv(l);
    char buf[MAX_STR]; int bi=0;
    while (lpeek(l) && lpeek(l)!=q) {
        if (lpeek(l)=='\\') {
            ladv(l);
            char e=ladv(l);
            switch(e){
                case 'n': buf[bi++]='\n'; break;
                case 't': buf[bi++]='\t'; break;
                case 'r': buf[bi++]='\r'; break;
                default:  buf[bi++]=e;    break;
            }
        } else buf[bi++]=ladv(l);
    }
    if (!lpeek(l)) lex_err(l,"Unterminated string");
    ladv(l);
    buf[bi]='\0';
    emit(l, DTOK_STRING, buf, 0,0,0);
}

static void lex_number(Lexer *l) {
    char buf[64]; int bi=0; int isf=0;
    while (isdigit(lpeek(l))||lpeek(l)=='_') { if(lpeek(l)!='_') buf[bi++]=lpeek(l); ladv(l); }
    if (lpeek(l)=='.'&&isdigit(lpeek2(l))) {
        isf=1; buf[bi++]=ladv(l);
        while(isdigit(lpeek(l))) buf[bi++]=ladv(l);
    }
    buf[bi]='\0';
    if (isf) emit(l, DTOK_FLOAT, buf, 0, atof(buf), 0);
    else      emit(l, DTOK_INT,   buf, atoll(buf), 0, 0);
}

DuckToken *duck_lex(const char *src, int *out_count) {
    DuckToken *tokens = (DuckToken*)calloc(MAX_TOKENS, sizeof(DuckToken));
    Lexer l = {0};
    l.src = src; l.line = 1; l.out = tokens;
    l.indent_stack[0] = 0;
    int at_sol = 1;

    while (lpeek(&l)) {
        if (at_sol) { handle_indent(&l); at_sol=0; }
        char c = lpeek(&l);
        if (c==' '||c=='\t') { ladv(&l); continue; }
        if (c=='\n') { emit(&l,DTOK_NEWLINE,"\\n",0,0,0); ladv(&l); at_sol=1; continue; }
        if (c=='#')  { while(lpeek(&l)&&lpeek(&l)!='\n') ladv(&l); continue; }
        if (c=='"'||c=='\'') { lex_string(&l,c); continue; }
        if (isdigit(c)) { lex_number(&l); continue; }
        if (isalpha(c)||c=='_') {
            char buf[MAX_STR]; int bi=0;
            while(isalnum(lpeek(&l))||lpeek(&l)=='_') buf[bi++]=ladv(&l);
            buf[bi]='\0';
            DuckTokType kt=DTOK_IDENT; int bv=0;
            for(KWEntry *kw=keywords; kw->kw; kw++) {
                if(strcmp(buf,kw->kw)==0){kt=kw->type;bv=kw->bval;break;}
            }
            emit(&l,kt,buf,0,0,bv);
            continue;
        }
        ladv(&l);
        switch(c){
            case '+': if(lpeek(&l)=='='){ladv(&l);emit(&l,DTOK_PLUS_EQ, "+=",0,0,0);}else emit(&l,DTOK_PLUS,  "+",0,0,0); break;
            case '-': if(lpeek(&l)=='='){ladv(&l);emit(&l,DTOK_MINUS_EQ,"-=",0,0,0);}else emit(&l,DTOK_MINUS, "-",0,0,0); break;
            case '*': if(lpeek(&l)=='*'){ladv(&l);emit(&l,DTOK_DSTAR,  "**",0,0,0);}
                      else if(lpeek(&l)=='='){ladv(&l);emit(&l,DTOK_STAR_EQ,"*=",0,0,0);}
                      else emit(&l,DTOK_STAR,"*",0,0,0); break;
            case '/': if(lpeek(&l)=='='){ladv(&l);emit(&l,DTOK_SLASH_EQ,"/=",0,0,0);}else emit(&l,DTOK_SLASH, "/",0,0,0); break;
            case '%': emit(&l,DTOK_PERCENT,"%",0,0,0); break;
            case '=': if(lpeek(&l)=='='){ladv(&l);emit(&l,DTOK_EQ,"==",0,0,0);}else emit(&l,DTOK_ASSIGN,"=",0,0,0); break;
            case '!': if(lpeek(&l)=='='){ladv(&l);emit(&l,DTOK_NEQ,"!=",0,0,0);} break;
            case '<': if(lpeek(&l)=='='){ladv(&l);emit(&l,DTOK_LE,"<=",0,0,0);}else emit(&l,DTOK_LT,"<",0,0,0); break;
            case '>': if(lpeek(&l)=='='){ladv(&l);emit(&l,DTOK_GE,">=",0,0,0);}else emit(&l,DTOK_GT,">",0,0,0); break;
            case '(': emit(&l,DTOK_LPAREN,  "(",0,0,0); break;
            case ')': emit(&l,DTOK_RPAREN,  ")",0,0,0); break;
            case '{': emit(&l,DTOK_LBRACE,  "{",0,0,0); break;
            case '}': emit(&l,DTOK_RBRACE,  "}",0,0,0); break;
            case '[': emit(&l,DTOK_LBRACKET,"[",0,0,0); break;
            case ']': emit(&l,DTOK_RBRACKET,"]",0,0,0); break;
            case ',': emit(&l,DTOK_COMMA,   ",",0,0,0); break;
            case ':': emit(&l,DTOK_COLON,   ":",0,0,0); break;
            case '.': emit(&l,DTOK_DOT,     ".",0,0,0); break;
            default: { char m[32]; snprintf(m,32,"Unknown char: '%c'",c); lex_err(&l,m); }
        }
    }
    while(l.indent_top>0){l.indent_top--;emit(&l,DTOK_DEDENT,"DEDENT",0,0,0);}
    emit(&l,DTOK_EOF,"EOF",0,0,0);
    *out_count = l.out_count;
    return tokens;
}
